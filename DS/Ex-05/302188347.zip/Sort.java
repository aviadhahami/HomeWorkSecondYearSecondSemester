
public interface Sort {
	public int[] sort(int [] input); 
}
