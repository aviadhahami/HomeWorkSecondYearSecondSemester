﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex05.Othello.UI
{
    public enum GameMode
    {
        AgainstFriend,
        AgainstComputer
    }
}
