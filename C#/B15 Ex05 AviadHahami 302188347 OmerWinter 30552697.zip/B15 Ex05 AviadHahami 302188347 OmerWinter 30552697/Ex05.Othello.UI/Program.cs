﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Ex05.Othello.UI
{
    class Program
    {
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.Run(new UIManager());
        }
    }
}
