﻿using System;
using System.Collections.Generic;
using System.Text;

namespace B15_EX3_AVIADHAHAMI_ID_OMERWINTER_ID
{
    class Garage
    {

        internal static void AppdateStatus(string p, StatusType statusType)
        {
            throw new NotImplementedException();
        }

        internal static bool Exist(string p)
        {
            throw new NotImplementedException();
        }

        internal static void Insert(string p, string p_2, StatusType statusType, Vehicle i_Vehicle)
        {
            throw new NotImplementedException();
        }
    }
}
