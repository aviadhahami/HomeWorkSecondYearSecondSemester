﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace B15_EX3_AVIADHAHAMI_ID_OMERWINTER_ID
{
    public enum FuelType
    {
        Soler,
        Octan95, 
        Octan96, 
        Octan98
    };
}
