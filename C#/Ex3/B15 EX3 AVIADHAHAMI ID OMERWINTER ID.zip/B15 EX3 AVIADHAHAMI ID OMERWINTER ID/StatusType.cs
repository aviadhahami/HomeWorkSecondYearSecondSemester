﻿using System;
using System.Collections.Generic;
using System.Text;

namespace B15_EX3_AVIADHAHAMI_ID_OMERWINTER_ID
{
    enum StatusType
    {
        Fixing,
        Fixed,
        Paid
    };
}
