﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex04.Menus.Interfaces
{
    public interface IPerformAction
    {
        void performAction(string i_ActionToInvokes);
    }
}
