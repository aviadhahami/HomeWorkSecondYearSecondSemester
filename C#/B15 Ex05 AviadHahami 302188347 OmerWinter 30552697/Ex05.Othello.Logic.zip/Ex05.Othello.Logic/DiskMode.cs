﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex05.Othello.Logic
{
    public enum DiskMode
    {
        Black = 0,
        White,
        IlegalMove,
        OptionalMove
    }
}
